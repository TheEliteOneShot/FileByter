/// <reference types="vite-plugin-pages/client" />
